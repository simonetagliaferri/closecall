package it.simonetagliaferri.beans;

public class TournamentBean {
    String name;
    String tournamentType;
    String tournamentFormat;
    String matchFormat;
}
