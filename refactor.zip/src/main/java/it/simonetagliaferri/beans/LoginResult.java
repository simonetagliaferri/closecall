package it.simonetagliaferri.beans;

public enum LoginResult {
    SUCCESS,
    FAIL
}
