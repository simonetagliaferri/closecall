package it.simonetagliaferri.model.domain;

public enum Role {
    PLAYER,
    HOST
}
