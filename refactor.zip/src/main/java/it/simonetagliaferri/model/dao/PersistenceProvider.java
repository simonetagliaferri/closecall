package it.simonetagliaferri.model.dao;

public enum PersistenceProvider {
    IN_MEMORY,
    JDBC,
    FS
}
