package it.simonetagliaferri.controller.graphic;

public enum UIMode {
    CLI,
    GUI
}
