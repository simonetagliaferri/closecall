package it.simonetagliaferri.controller.graphic.cli;

public class GraphicPlayerDashboardControllerCLI {
}
