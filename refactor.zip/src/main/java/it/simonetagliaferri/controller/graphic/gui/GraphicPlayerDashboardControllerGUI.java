package it.simonetagliaferri.controller.graphic.gui;

public class GraphicPlayerDashboardControllerGUI {
}
